package com.stockapp.service.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.stockapp.entity.Company;
import com.stockapp.entity.Manager;
import com.stockapp.repository.IManagerDao;
import com.stockapp.service.IManagerServiceImpl;

@SpringBootTest
public class ManagerServiceTest {
	@Autowired
	private IManagerServiceImpl managerService;

	@MockBean
	private IManagerDao managerRepository;

	@Test
	@DisplayName("Test for displaying all manager details")
	public void showAllManagerDetailsTest() {

		
		Company company = new Company(1, "Amazon");
		Manager manager = new Manager(1, "ram", "ram@gamil.com",  "9444944494", company);
		Manager manager1 = new Manager(200, "ram", "ram@gamil.com",  "9444944494",company);

		when(managerRepository.findAll()).thenReturn(Stream
				.of(manager,
						manager1)
				.collect(Collectors.toList()));
		assertEquals(2, managerService.getAllManager().size());
	}
	

	@Test
	@DisplayName("Test for adding manager")
	public void addManagerTest() {
		Company company = new Company();
		company.setCompanyId(1); 	company.setCompanyName("MyCompany");
		Manager manager = new Manager();
		manager.setCompany(company); manager.setEmail("ram@gmail.com"); 	manager.setManagerId(0); 	manager.setManagerName("managerName"); 	manager.setMobileNo("9902394999");
	
		//Manager ma=Optional.of(manager);
		
		Mockito.when(managerRepository.save(manager)).thenReturn(manager);
		//System.out.println(manager);
		//assertEquals(true, managerService.addManager(manager));
		assertThat(managerService.addManager(manager)).isEqualTo(true);
	}

	@Test
	@DisplayName("Test for updating manager")
	public void updateManagerTest() {
		Company company = new Company(1, "Amazon");
		Manager manager = new Manager(1, "Surajit", "Sm@gmail.com",  "9876543210", company);
		manager.setManagerName("Surendra");
		assertThat(managerRepository.findById(manager.getManagerId())).isNotEqualTo(manager);
	}

	@Test
	@DisplayName("Test for deleting manager")
	public void deleteManagerTest() {
		Company company = new Company(1, "Amazon");
		Manager manager = new Manager(1, "Surajit", "Sm@gmail.com",  "9876543210", company);
		when(managerRepository.existsById(manager.getManagerId())).thenReturn(true);
		managerService.deleteManager(manager.getManagerId());
		verify(managerRepository).deleteById(1);
	}

	@Test
	@DisplayName("Test for get manager details by Id")
    public void getManagerDetailsTest() {
		Company company = new Company(1, "Amazon");
		Manager manager = new Manager(1, "Surajit", "shyam@gmail.com",  "9876543210", company);
		when(managerRepository.save(manager)).thenReturn(manager);
		assertNotEquals(manager, managerRepository.findById(manager.getManagerId()));

	}
}

