package com.stockapp.service.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.stockapp.entity.Investor;
import com.stockapp.repository.InvestorDao;
import com.stockapp.service.InvestorServiceImpl;


@SpringBootTest
class InvestorServiceTest {
	@Autowired
	private InvestorServiceImpl investorServiceImpl;
	
	@MockBean
	private InvestorDao investorDao;
	
	@Test
	public void addInvestorTest() {
		Investor investor=new Investor(1,"Som","som@gmail.com","90807060","Male");
		Mockito.when(investorDao.save(investor)).thenReturn(investor);
		assertThat(investorServiceImpl.addInvestor(investor)).isEqualTo("Investor added Successfully");
	}
	
//	public void getAllInvestorTest() {
//		Investor investor=new Investor(1,"Som","som@gmail.com","90807060","Male");
//		Mockito.when(investorDao.findAll()).thenReturn(investor);
//	}
//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}

}
