package com.stockapp.service.test;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.stockapp.entity.User;
import com.stockapp.repository.IUserDao;
import com.stockapp.service.IUserServiceImpl;




@SpringBootTest
public class UserServiceTest
{
		@Autowired
		private IUserServiceImpl userService;

		@MockBean
		private IUserDao userRepository;

		@Test
		@DisplayName("Test for adding user")
		public void addUserTest() {
			User user = new User(123, "Ramesh", "king@123", "admin");
			when(userRepository.save(user)).thenReturn(user);
			assertEquals(true, userService.createUser(user));
		}

		@Test
		@DisplayName("Test for updating user")
		public void updateUserTest() {
			User user = new User(123, "Ramesh", "king@123", "admin");
//			when(userRepository.save(user)).thenReturn(user);
//			assertEquals(true,userService.updateUser(user));
			user.setUserName("RameshKumar");
			assertThat(userRepository.findById(user.getUserId())).isNotEqualTo(user);
		}

		@Test
		@DisplayName("Test for deleting user")
		public void removeUserTest() {
			// userService.removeUser(123457L);
			// verify(userRepository, times(1)).deleteById(1234567L);
			User user = new User(123, "Ramesh", "king@123", "admin");
			when(userRepository.existsById(user.getUserId())).thenReturn(true);
			userService.removeUser(user);
			verify(userRepository).deleteById(123);
		}

	}


