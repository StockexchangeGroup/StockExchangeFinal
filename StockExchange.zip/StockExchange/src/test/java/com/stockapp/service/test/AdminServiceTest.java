package com.stockapp.service.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.stockapp.entity.Admin;
import com.stockapp.repository.IAdminDao;
import com.stockapp.service.IAdminService;


@SpringBootTest
public class AdminServiceTest {

	@Autowired
	private IAdminService adminservice;
	@MockBean
	private IAdminDao adminDao;

	@Test
	@DisplayName("Test for adding admin")
	public void addAdminTest() {
		Admin admin = new Admin(12, "Lucifer", "lucifer@gmail.com", "Lucifer@987");
		when(adminDao.save(admin)).thenReturn(admin);
		assertEquals(true, adminservice.addAdmin(admin));
	}

	@Test
	@DisplayName("Test for updating  admin")
	public void updateAdminTest() {
		Admin admin = new Admin(12, "Lucifer", "lucifer@gmail.com", "Lucifer@987");
		admin.setAdminName("RameshKumar");
		assertThat(adminDao.findById(admin.getAdminId())).isNotEqualTo(admin);
	}

	@Test
	@DisplayName("Test for removing admin")
	public void addRemoveTest() {
		Admin admin = new Admin(12, "Lucifer", "lucifer@gmail.com", "Lucifer@987");
		when(adminDao.existsById(admin.getAdminId())).thenReturn(true);
		adminservice.deleteAdmin(admin.getAdminId());
		verify(adminDao).deleteById(12);
	}

}
