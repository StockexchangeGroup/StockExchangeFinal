package com.stockapp.exception.handler;

import java.util.LinkedHashMap;
import java.util.Map;
import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.stockapp.exceptions.DuplicateUserException;
import com.stockapp.exceptions.UserNotFoundException;

@ControllerAdvice
public class UserErrorHandler extends ResponseEntityExceptionHandler
{
	@ExceptionHandler(DuplicateUserException.class)
	public ResponseEntity<?> handleDuplicateUser(DuplicateUserException due) {
		Map<String, Object> errorbody = new LinkedHashMap<>();
		errorbody.put("error", "Creation failed");
		errorbody.put("timestamp", LocalDateTime.now());
		errorbody.put("details", due.getMessage());

		return new ResponseEntity<>(errorbody, HttpStatus.CONFLICT);
	}
	
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<?> handleMissingUser(UserNotFoundException une) {
		Map<String, Object> errorbody = new LinkedHashMap<>();
		errorbody.put("error", une.getOperation()+" failed");
		errorbody.put("timestamp", LocalDateTime.now());
		errorbody.put("details", une.getMessage());

		return new ResponseEntity<>(errorbody, HttpStatus.NOT_FOUND);
	}
}
