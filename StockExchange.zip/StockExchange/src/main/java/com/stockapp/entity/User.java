package com.stockapp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;


@Entity
@Table(name = "userss")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "USER_ID", updatable = false, nullable = false )
	private int userId;
	
	@NotNull
	@Length(min = 4, max = 20, message = "Username should be from 4 to 20 characters")
	@Pattern(regexp = "^[A-Za-z]+[A-Za-z_0-9]*$", message = "Username should not contain any special characters")
	@Column(name = "USER_NAME")
	private String userName;
	
	@NotNull
	@Length(min = 6, max = 20, message = "Password should be from 6 to 20 characters")
	@Pattern(regexp = "[A-Za-z0-9]+[!@#$%^&*]+[A-Za-z0-9]+", message = "Password should contain atleast contain a digit and a special character")
	@Column(name = "PASSWORD")
	private String password;
	
	@NotNull
	@Pattern(regexp = "(Admin|Investor|Manager)", message = "Role must be admin or investor or manager")
	@Column(name = "ROLE")
	private String role;// admin or investor or manager

	public User(int userId, String userName, String password, String role) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.role = role;
	}
	public User() {
		super();
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", password=" + password + ", role=" + role + "]";
	}
}