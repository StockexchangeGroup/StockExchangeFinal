package com.stockapp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import com.sun.istack.NotNull;


@Entity
@Table(name="company")
public class Company {

	@Id
	@GeneratedValue
	@Column(name = "COMPANY_ID", nullable = false)
	private int companyId;
	
	@NotNull
	@Column(name = "COMPANY_NAME")
	private String companyName;
	
	@OneToOne(mappedBy = "company")
	private Stock stock;
	
	@OneToOne(mappedBy = "company")
	private Manager manager;
	
	public Company(int companyId, String companyName) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
	}

	public Company() {
		super();
	}
	
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + "]";
	}
	
	
}
