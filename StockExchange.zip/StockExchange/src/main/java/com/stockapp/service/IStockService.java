package com.stockapp.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.stockapp.entity.Investor;
import com.stockapp.entity.Stock;

@Service
public interface IStockService {
	
	public boolean addStockDetails(Stock stock);
	public boolean updateStockDetails(Stock stock);
	public boolean removeStockDetails(Stock stock);
	public Stock viewStockDetails(Stock stock);
	public List<Stock> viewAllStockDetails();
	public List<Stock> viewStockByCompanyName(String name);
	public List<Stock> viewStockByInvestor(Investor inv);
	public List<Stock> viewAllGrowingStocks(); // stocks where the price is increased 
	public List<Stock> viewAllReducingStocks();// stocks where the price is reduced.
	public Stock viewStockDetails(int stockId);
	public boolean removeStockDetails(int id);
	
}
