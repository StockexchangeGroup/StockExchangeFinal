package com.stockapp.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stockapp.repository.IUserDao;
import com.stockapp.entity.User;
import com.stockapp.exceptions.DuplicateUserException;
import com.stockapp.exceptions.UserNotFoundException;

@Service
public class IUserServiceImpl implements IUserService
{

	@Autowired
	IUserDao userDao;
	
	
	Logger logger = LoggerFactory.getLogger(IUserServiceImpl.class);
	
	//Add the User
	@Override
	public boolean createUser(User user) {
		 logger.info("addUser() invoked");
		if(userDao.existsById(user.getUserId())) {
			 logger.warn("DuplicateUserException thrown...Creation Failed, User already exists with id "+user.getUserId());
			throw new DuplicateUserException("User already exists with id "+user.getUserId());
		} 
		else {
			userDao.save(user);
			 logger.info("A new user has been added");
			return true;
		}
	}

	//Remove the User
	@Override
	public boolean removeUser(User user)
	{
		 logger .info("removeUser() invoked");
		if(userDao.existsById(user.getUserId())) {
			userDao.deleteById(user.getUserId());
			 logger .info("User with id "+user.getUserId()+" removed");
			return true;
		}
		else {
			 logger .warn("UserNotFoundException thrown...Delete Failed, User not found with id "+user.getUserId());
			throw new UserNotFoundException("Delete","User not found with id "+user.getUserId());
		}
	}

	//Update the User
	@Override
	public boolean updateUser(User user) {
		 logger .info("updateUser() invoked");
		if(userDao.existsById(user.getUserId())) {
			userDao.save(user);
			 logger .info("User with id "+user.getUserId()+" updated");
			return true;
		}
		else {
			 logger .warn("UserNotFoundException thrown...Delete Failed, User not found with id "+user.getUserName());
			throw new UserNotFoundException("Update","User not found with id "+user.getUserId());
		}
	}

	//Login method
	@Override
	public User login(String username, String password) {
		 logger .info("login() invoked");
		User user = userDao.findByUserNameAndPassword(username, password);
		if(user == null) {
			 logger .error("UserNotFoundException thrown...Login Failed, username or password is incorrect");
			throw new UserNotFoundException("Login","username or password is incorrect");
		}
		else {
			 logger .info("User "+username+" has logged in successfully ");
			return user;
		}
	}

	//Logout Method
	@Override
	public String logout(User user) {
		 logger .info("logout() invoked");
		 logger .info("User "+user.getUserName()+" has been logged out");
		return "User "+user.getUserName()+" has been logged out";
	}

}

