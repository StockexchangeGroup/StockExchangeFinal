package com.stockapp.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stockapp.exceptions.DuplicateManagerException;
import com.stockapp.exceptions.EmptyTableException;
import com.stockapp.exceptions.ManagerNotFoundException;
import com.stockapp.entity.Company;
import com.stockapp.entity.Manager;
import com.stockapp.repository.ICompanyDao;
import com.stockapp.repository.IManagerDao;


@Service
public class IManagerServiceImpl implements IManagerService {

	@Autowired
	IManagerDao managerDao;

	@Autowired
	ICompanyDao companyDao;

	 public static  final Logger LOGGER = LoggerFactory.getLogger(IManagerService.class);
	@Override
	//addmanager
	public boolean addManager(Manager manager) {
		
		// TODO Auto-generated method stub
		LOGGER.info("addManager() has been invoked");
			
		if (managerDao.existsById(manager.getManagerId())) {
			LOGGER.warn("DuplicateManagerException : Creation failed, Manager already exists with id "+manager.getManagerId());
			throw new DuplicateManagerException("Manager already exists with id " + manager.getManagerId());
		}
		else {
			managerDao.save(manager);
			LOGGER.info("Manager with id "+manager.getManagerId()+" has been added");
			return true;
		}
		
	}

	@Override
	//getAllManager
	public List<Manager> getAllManager() {
		// TODO Auto-generated method stub
		LOGGER.info("getAllManager() has been invoked");
		List<Manager> managerList = managerDao.findAll();
		if(managerList.isEmpty()) {
			LOGGER.warn("EmptyTableException : No data found in the database");
			throw new EmptyTableException("No Data Found in the database");
		}
		else {
			LOGGER.info("All managers have been returned");
			return managerList;
		}
		
	}

	@Override
	//getManagerDetails
	public Optional<Manager> getManagerDetails(int managerId) {
		LOGGER.info("getManagerDetails() has been invoked");
		if(managerDao.findAll().isEmpty()){
			LOGGER.warn("EmptyTableException : No data found in the database");
			throw new EmptyTableException("No Data Found in the database");
		}
		if(managerDao.existsById(managerId)) {
			LOGGER.info("Manager with id "+managerId+" has been returned");
			return managerDao.findById(managerId);
		}
		else {
			LOGGER.warn("ManagerNotFoundException : Request falied, Manager not found with id "+managerId);
			throw new ManagerNotFoundException("Request", "Manager not found with id " + managerId);
		}
		// TODO Auto-generated method stub
		//return null;
	}

	@Override
	//updateManager
	public  boolean   updateManager(Manager manager) {
		LOGGER.info("updateManager() has been invoked");
		
		if (managerDao.existsById(manager.getManagerId())) {
			managerDao.save(manager);
			LOGGER.info("Manager with id "+manager.getManagerId()+" has been updated");
			return true;
		} else {
			LOGGER.info("ManagerNotFoundException : Update failed, Manager not found with id "+manager.getManagerId());
			throw new ManagerNotFoundException("Update", "Manager not found with id " + manager.getManagerId());
		}
		// TODO Auto-generated method stub
		//return null;
	}

	@Override
	//deleteManager
	public boolean  deleteManager(int managerId) {
		LOGGER.info("deleteManager() has been invoked");
		if (managerDao.existsById(managerId)) {
			managerDao.deleteById(managerId);
			LOGGER.info("Manager with id "+managerId+" has been deleted");
			return true;
		} else {
			LOGGER.warn("ManagerNotFoundException : Delete failed, Manager not found with id "+managerId);
			throw new ManagerNotFoundException("Delete", "Manager not found with id " + managerId);
		}
		// TODO Auto-generated method stub
		//return null;
	}

	@Override
	//getmanager
	public Manager getManager(Company company) {
		LOGGER.info("getManager() has been invoked");
		Manager manager= managerDao.findByCompany(company);
		if(manager == null) {
			LOGGER.warn("ManagerNotFoundException : Request failed, Manager not found for the company "+company.getCompanyName());
			throw new ManagerNotFoundException("Request", "Manager not found for the company "+company.getCompanyName());
		}
		else {
			LOGGER.info("Manager of company "+company.getCompanyName()+" has been returned");
			return manager;
		}
	
		// TODO Auto-generated method stub
		//return null;
	}
}
