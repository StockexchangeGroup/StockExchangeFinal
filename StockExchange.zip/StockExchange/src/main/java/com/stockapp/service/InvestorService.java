package com.stockapp.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.stockapp.entity.Investor;


@Service
public interface InvestorService {
	
	public String addInvestor(Investor info);
	public  List<Investor> getAllInvestor();
	public Investor getInvestorDetails(int investorId);
	public String  updateInvestor(Investor info);
	public String deleteInvestor(Investor inv);
	public Map<Integer,String> viewAllInvestorByStock(int stockId);
	public Map<Integer,String> viewAllInvestorByCompany(int companyId);
	public String buyStock(int stockId ,int investorId,int quantity);
	public String sellStock(int stock ,int investor,int quantity);

	
}