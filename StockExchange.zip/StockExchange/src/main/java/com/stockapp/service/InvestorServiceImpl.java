package com.stockapp.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stockapp.exceptions.InvestorNotFoundException;
import com.stockapp.exceptions.StockNotFoundException;
import com.stockapp.entity.Investor;
import com.stockapp.entity.Stock;
import com.stockapp.entity.Transaction;
import com.stockapp.exceptions.CompanyNotFoundException;
import com.stockapp.exceptions.EmptyTableException;
import com.stockapp.exceptions.InsufficientSharesException;
import com.stockapp.repository.ICompanyDao;
import com.stockapp.repository.IStockDAO;
import com.stockapp.repository.ITransactionDao;
import com.stockapp.repository.InvestorDao;


@Service
public class InvestorServiceImpl implements InvestorService{

	@Autowired
	InvestorDao investorDao;
	
	@Autowired
	IStockDAO stockDao;
	
	@Autowired
	ICompanyDao companyDao;
	
	@Autowired
	ITransactionDao transactionDao;
	
	Logger log=LoggerFactory.getLogger(InvestorServiceImpl.class);

	//Add the investor
	@Override
	public String addInvestor(Investor info) {
		log.info("addInvestor() invoked");
		investorDao.save(info);
		log.info("A new investor with id : "+info.getInvestorId()+" has been added");
			
		return "Investor added Successfully";
	}

	//display all Investors
	@Override
	public List<Investor> getAllInvestor() {
		log.info("getAllInvestor() invoked");
		List<Investor> investorsList=investorDao.findAll();
		if(investorsList.isEmpty()) {
			log.warn("EmptyTableException : no data found in the database");
			throw new EmptyTableException("No data found in the Database");
		}
		else {
			log.info("Investors List is returned");
			return investorsList;
		}
	}

	//Display investor details
	@Override
	public Investor getInvestorDetails(int investorId) {
		log.info("getInvestorDetails() invoked");
		if(investorDao.existsById(investorId)) {
			return investorDao.findById(investorId).get();
		}
		else {
			log.warn("InvestorNotFoundException : Investor not found with id : "+investorId);
			throw new InvestorNotFoundException("getInvestorDetails","Investor not found with id : "+investorId);
		}
	}

	//Update Investor
	@Override
	public String updateInvestor(Investor info){
		log.info("updateInvestor() invoked");
		if(investorDao.existsById(info.getInvestorId())) {
			log.info("Investor with id : "+info.getInvestorId()+" has been updated");
			investorDao.save(info);
			return "Investor Updated Successfully";
		}
		else {
			log.warn("InvestorNotFoundException : Update failed , Investor not found with id : "+info.getInvestorId());
			throw new InvestorNotFoundException("Update failed : Investor","Investor not found with id : "+info.getInvestorId());
		}
	}

	//Delete Investor
	@Override
	public String deleteInvestor(Investor inv) {
		log.info("deleteInvestor() invoked");
		if(investorDao.existsById(inv.getInvestorId())) {
			Investor investor=investorDao.findById(inv.getInvestorId()).get();
			investorDao.delete(investor);
			return "Investor Deleted Successfully";
		}
		else {
			log.warn("InvestorNotFoundException : Delete Failed , Investor not found with id : "+inv.getInvestorId());
			throw new InvestorNotFoundException("Delete Failed : Investor"," Investor not found with id : "+inv.getInvestorId());
			
		}
	}

	@Override
	public Map<Integer,String> viewAllInvestorByStock(int stockId) {
		log.info("viewAllInvestor() by stock invoked");
		if(!stockDao.existsById(stockId)) {
			log.warn("StockNotFoundException : Stock not found with id : "+stockId);
			throw new StockNotFoundException("viewAllInvestor(stockId) failed ","Stock not found with id : "+stockId);
		}
		else {
			
			List<Integer> investorsId=transactionDao.findAll().stream()
									.filter(transaction -> transaction.getStockId()==stockId)
									.map(Transaction :: getInvestorId).collect(Collectors.toList());
			
			if(investorsId.isEmpty()) {
				log.warn("InvestorNotFoundException : No Investor found with Stock id "+stockId);
				throw new InvestorNotFoundException("viewAllInvestorByStock(stockId) failed ","No Investor found with Stock id "+stockId);
			}
			else {
				Map<Integer,String> investorData=new HashMap<Integer, String>();
				for(int id : investorsId) {
					Investor investor=investorDao.findById(id).get();
					investorData.put(id, investor.getInvestorName());
				}
				return  investorData;
			}
		}
	}

	//View all investor by company
	@Override
	public Map<Integer,String> viewAllInvestorByCompany(int companyId) {
		log.info("viewAllInvestor() by Company invoked");
		if(!companyDao.existsById(companyId)) {
			log.warn("No Company Found with id : "+companyId);
			throw new CompanyNotFoundException("viewInvestorByComapnyID","No Company Found with id : "+companyId);
		}
		else {
			List<Integer> stockId=stockDao.findAll().stream()
						.filter(stock -> stock.getCompany().getCompanyId() == companyId)
						.map(Stock :: getStockId).collect(Collectors.toList());
			List<Integer> investorId=transactionDao.findAll().stream()
										.filter(transaction -> transaction.getStockId()==stockId.get(0))
										.map(Transaction :: getInvestorId).collect(Collectors.toList());
			Map<Integer,String> investorsData=new HashMap<>();
			for(int id : investorId) {
				Investor investor=investorDao.findById(id).get();
				investorsData.put(id, investor.getInvestorName());
			}
			
			return investorsData;
		}
	}

	//buyStock
	@Override
	public String buyStock(int stockId, int investorId, int quantity) {
		log.info("buyStock() invoked");
		if(!stockDao.existsById(stockId)) {
			log.warn("No Stock Found with id : "+stockId);
			throw new StockNotFoundException("buyStock() failed","No Stock Found with id : "+stockId);
		}
		if(!investorDao.existsById(investorId)) {
			log.warn("No Investor Found with id : "+investorId);
			throw new InvestorNotFoundException("buyStock() failed","Investor not found with id : "+investorId);
		}
		
		int availableQuantity=stockDao.findById(stockId).get().getQuantity();
		if(availableQuantity < quantity) {
			log.warn("InsufficientSharesException : Stock with id : "+stockId+" has insufficient shares");
			throw new InsufficientSharesException("Stock with id : "+stockId+" has insufficient shares");
		}
		else {
		Stock stock=stockDao.findById(stockId).get();
		Investor investor=investorDao.findById(investorId).get();
		
		
		Transaction transaction = new Transaction(LocalDateTime.now(),"Buy",stockId,investorId,quantity);
		transactionDao.save(transaction);

		stock.setQuantity(availableQuantity - quantity);
		stockDao.save(stock);
		
		log.info("Investor "+investor.getInvestorName()+" has bought "+quantity+" shares of "+stock.getCompany().getCompanyName());
		return "Investor "+investor.getInvestorName()+" has bought "+quantity+" shares of "+stock.getCompany().getCompanyName();
		}
	}

	//sellStock
	@Override
	public String sellStock(int stockId, int investorId, int quantity) {
		log.info("sellStock() invoked");
		if(!stockDao.existsById(stockId)) {
			log.warn("No Stock Found with id : "+stockId);
			throw new StockNotFoundException("sellStock() failed","No Stock Found with id : "+stockId);
		}
		if(!investorDao.existsById(investorId)) {
			log.warn("No Investor Found with id : "+investorId);
			throw new InvestorNotFoundException("sellStock() failed","Investor not found with id : "+investorId);
		}
		
		Stock stock=stockDao.findById(stockId).get();
		Investor investor=investorDao.findById(investorId).get();
	
		int boughtQuantity=transactionDao.findAll()
							.stream().filter(transaction->transaction.getTrasanctionType().equals("Buy") && transaction.getInvestorId()==investorId)
							.mapToInt(transaction->transaction.getQuantity()).sum();
		
		int soldQuantity=transactionDao.findAll()
				.stream().filter(transaction->transaction.getTrasanctionType().equals("Sell") && transaction.getInvestorId()==investorId)
				.mapToInt(transaction->transaction.getQuantity()).sum();
		
		int total=boughtQuantity-soldQuantity;
		if(total < quantity) {
			log.warn("Insufficient stocks with investor id : "+investorId);
			throw new InsufficientSharesException("Insufficient stocks with investor id : "+investorId);
		}
		else {
			Transaction transaction=new Transaction(LocalDateTime.now(),"Sell",stockId,investorId,quantity);
			transactionDao.save(transaction);
			
			stock.setQuantity(stock.getQuantity()+quantity);
			stockDao.save(stock);
			
			log.info("Investor : "+investor.getInvestorName()+" has sold "+quantity+" shares of "+stock.getCompany().getCompanyName());
			
			return "Investor : "+investor.getInvestorName()+" has sold "+quantity+" shares of "+stock.getCompany().getCompanyName();
		}
	}
}
