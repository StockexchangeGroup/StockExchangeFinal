package com.stockapp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.stockapp.entity.Admin;

@Service
public interface IAdminService {
	
	  public List<Admin> getAdmins();
	  
	  public Admin getAdmin(int adminId);
	  public boolean addAdmin(Admin admin);
	  public boolean deleteAdmin(int adminId);
	  public boolean updateAdmin(Admin admin);
	
	  
	 
}
