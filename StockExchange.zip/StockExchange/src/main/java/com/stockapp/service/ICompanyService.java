package com.stockapp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.stockapp.entity.Company;



@Service
public interface ICompanyService {

	public boolean addCompanyInfo(Company info);
	public List<Company> getAllCompanyInfo();
	public Company getCompanyDetails(int companyId);
	public boolean updateCompanyInfo(Company info);
	public boolean deleteCompanyInfo(int companyId);

}