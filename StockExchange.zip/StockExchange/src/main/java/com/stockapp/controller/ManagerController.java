package com.stockapp.controller;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockapp.entity.Company;
import com.stockapp.entity.Manager;
import com.stockapp.service.IManagerServiceImpl;



@RestController
@RequestMapping("/manager")
public class ManagerController {

	@Autowired
	IManagerServiceImpl manager1;
	
	
	@PostMapping
	public ResponseEntity<?> addManager(@Valid @RequestBody Manager manager, BindingResult result) {
		if(result.hasErrors()){
			return new ResponseEntity(result.getFieldErrors().stream().map(FieldError::getDefaultMessage).collect(Collectors.toList()),HttpStatus.BAD_REQUEST);
		}
		manager1.addManager(manager);
		return new ResponseEntity<String>("Manager added successfully",HttpStatus.OK);
	}
	@GetMapping("{managerId}")
	public Optional<Manager> getManagerDetails(@PathVariable("managerId") int managerId) {
		return manager1.getManagerDetails(managerId);
	}
	@GetMapping("/company")
	public ResponseEntity<Manager> getManager(@Valid @RequestBody Company company , BindingResult result) {
		if(result.hasErrors()){
			return new ResponseEntity(result.getFieldErrors().stream().map(FieldError::getDefaultMessage).collect(Collectors.toList()),HttpStatus.BAD_REQUEST);
		}
		Manager manager=manager1.getManager(company);
		return new ResponseEntity<Manager>(manager,HttpStatus.OK);
	}
	
	@GetMapping
	public List<Manager> getAllManager(){
		return manager1.getAllManager();
	}
	
	@PutMapping
	public ResponseEntity<?> updateManager(@Valid @RequestBody Manager manager, BindingResult result) {
		if(result.hasErrors()){
			return new ResponseEntity<>(result.getFieldErrors().stream().map(FieldError::getDefaultMessage).collect(Collectors.toList()),HttpStatus.BAD_REQUEST);
		}
		manager1.updateManager(manager);
		return new ResponseEntity<String>("Manager with id "+manager.getManagerId()+" updated successfully",HttpStatus.OK);
 	}
	
	@DeleteMapping("{managerId}")
	public String deleteManager(@PathVariable int managerId) {
		manager1.deleteManager(managerId);
		return "Manager with id "+managerId+" has been deleted successfully";
	}

	

}
