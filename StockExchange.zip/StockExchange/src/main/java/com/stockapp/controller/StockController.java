package com.stockapp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockapp.service.IStockServiceImpl;
import com.stockapp.entity.Investor;
import com.stockapp.entity.Stock;


@RestController
@RequestMapping("/stocks") 
public class StockController {

	@Autowired
	IStockServiceImpl stockServiceImpl;
	

	@GetMapping
	public List<Stock> viewAllStock() {
		return stockServiceImpl.viewAllStockDetails();
	}

	@GetMapping("{stockId}")
	public Stock viewStockDetails(@PathVariable("stockId") int stockId) {
		return stockServiceImpl.viewStockDetails(stockId);
	}

	@GetMapping("/company/{companyName}")
	public List<Stock> viewStockByCompany(@PathVariable("companyName") String companyName){
		return stockServiceImpl.viewStockByCompanyName(companyName);
	}
	
	@PostMapping("/investor")
	public List<Stock> viewStockByInvestor(@Valid @RequestBody Investor inv){
		return stockServiceImpl.viewStockByInvestor(inv);
	}
	
	@PostMapping("/growingstock")
	public List<Stock> viewAllGrowingStocks(){
		return stockServiceImpl.viewAllGrowingStocks();
	}

	@PostMapping("/reducingstock")
	public List<Stock> viewAllReducingStocks(){
		return stockServiceImpl.viewAllReducingStocks();
	}
	
//	@PostMapping("/growingstock/{limit}")
//	public List<Stock> viewAllGrowingStocks(@PathVariable("limit") int limit){
//		return stockServiceImpl.viewAllGrowingStocks(limit);
//	}
//
//	@PostMapping("/reducingstock/{limit}")
//	public List<Stock> viewAllReducingStocks(@PathVariable("limit") int limit){
//		return stockServiceImpl.viewAllReducingStocks(limit);
//	}


	@PostMapping
	public String addStock(@Valid @RequestBody Stock stock) {
		stockServiceImpl.addStockDetails(stock);
		return "Stock added successfully";
	}

	@PutMapping
	public String updateStock(@Valid @RequestBody Stock stock) {
		stockServiceImpl.updateStockDetails(stock);
		return "Stock details updated successfully";
	}

	@DeleteMapping("{stockid}")
	public String removeStock(@PathVariable("stockid") int id) {
		stockServiceImpl.removeStockDetails(id);
		return "Stock Data successfully deleted";
	}
}
