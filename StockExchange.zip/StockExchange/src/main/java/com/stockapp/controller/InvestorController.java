package com.stockapp.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockapp.entity.Investor;
import com.stockapp.service.InvestorServiceImpl;



@RestController
@RequestMapping("/root")
public class InvestorController {

	@Autowired
	InvestorServiceImpl investorServiceImpl;
	
	@PostMapping(path = "/addInvestor")
	public String addInvestor(@RequestBody Investor investor) {
		return investorServiceImpl.addInvestor(investor);
	}
	
	@GetMapping(path = "/getAllInvestor")
	public ResponseEntity<List<Investor>> getAllInvestor(){
		List<Investor> allInvestors=investorServiceImpl.getAllInvestor();
		return new ResponseEntity<List<Investor>>(allInvestors,HttpStatus.OK);
	}
	
	@GetMapping(path = "/getInvestorDetails/{investorId}")
	public ResponseEntity<Investor> getInvestorDetails(@PathVariable int investorId){
		Investor investor=investorServiceImpl.getInvestorDetails(investorId);
		return new ResponseEntity<Investor>(investor,HttpStatus.OK);
	}
	
	@PutMapping(path = "/updateInvestor")
	public String updateInvestor(@RequestBody Investor info) {
		return investorServiceImpl.updateInvestor(info);
	}
	
	@DeleteMapping(path = "/deleteInvestor")
	public String deleteInvestor(@RequestBody Investor inv) {
		return investorServiceImpl.deleteInvestor(inv);
	}
	
	@GetMapping(path = "/viewAllInvestorByStock/{stockId}")
	public ResponseEntity<Map<Integer,String>> viewAllInvestorByStock(@PathVariable int stockId){
		Map<Integer,String> investorsData=investorServiceImpl.viewAllInvestorByStock(stockId);
		return new ResponseEntity<Map<Integer,String>>(investorsData,HttpStatus.OK);
	}
	
	@GetMapping(path = "/viewAllInvestorByCompany/{companyId}")
	public ResponseEntity<Map<Integer,String>> viewAllInvestorByCompany(@PathVariable int companyId){
		Map<Integer,String> investorsData=investorServiceImpl.viewAllInvestorByCompany(companyId);
		return new ResponseEntity<Map<Integer,String>>(investorsData,HttpStatus.OK);
	}
	
	@PostMapping(path = "/buyStock/{stockId}/{investorId}/{quantity}")
	public String buyStock(@PathVariable int stockId,
												@PathVariable int investorId,
												@PathVariable int quantity){
		return investorServiceImpl.buyStock(stockId, investorId, quantity);
	}
	
	@PostMapping(path = "/sellStock/{stockId}/{investorId}/{quantity}")
	public String sellStock(@PathVariable int stockId,
												@PathVariable int investorId,
												@PathVariable int quantity){
		return investorServiceImpl.sellStock(stockId, investorId, quantity); //investorServiceImpl.sellStock(stockId, investorId, quantity);
	}
}
