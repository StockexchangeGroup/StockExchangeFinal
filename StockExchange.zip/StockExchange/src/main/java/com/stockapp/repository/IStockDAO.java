package com.stockapp.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
//import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stockapp.entity.Company;
import com.stockapp.entity.Stock;


@Repository
public interface IStockDAO extends JpaRepository<Stock, Integer>{

	List<Stock> findByCompany(Company company);
	
//	public Stock addStockDetails(Stock stock);
//	public Stock updateStockDetails(Stock stock);
//	public Stock removeStockDetails(Stock stock); 
//	public Stock viewStockDetails(Stock stock);
//	public List<Stock> viewAllStockDetails();
//	public Stock viewStockByCompanyName(String name);
//	public List<Stock> viewStockByInvestor(Investor inv);
//	public List<Stock> viewAllGrowingStocks(); // stocks where the price is increased 
//	public List<Stock> viewAllReducingStocks();// stocks where the price is reduced.
	
	// for finding the top growing stocks id 
	@Query(value = "SELECT * FROM STOCK order by stock_id desc limit :limits", nativeQuery = true)
	public List <Stock> findTopNStocks(@Param("limits") Integer limits);
	 
	@Query(value = "SELECT s.avg_price FROM STOCK s WHERE s.stock_id = :stockid", nativeQuery = true)	
	double findExistStockprice(@Param("stockid") Integer stockid);

	@Query(value = "SELECT * FROM STOCK s WHERE s.type = :type", nativeQuery = true)
	List<Stock> findGrowingReducingStocks(@Param("type") String stocktype);
	
	//@Query(value = "SELECT * FROM STOCK order by stock_id desc", nativeQuery = true)
	//public List <Stock> findTopNStocks();
}
