
package com.stockapp.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.stockapp.entity.Company;
//import com.cg.stockapp.dto.User;

@Repository
public interface ICompanyDao extends JpaRepository<Company, Integer>{
	
	public boolean existsByCompanyName(String companyName);

	public Company findByCompanyName(String companyName);
	
	//public List<Company> getAllCompanyInfo();
	
	//public boolean deleteById(int companyId);
	
	//public boolean existsById(int companyId);
	
	//public Company findByCompanyName(String companyName);

	       //public String getCompanyId();

//	public Company addCompanyInfo(Company info);			
//	public List<Company> getAllCompanyInfo();
//	public Company getCompanyDetails(String companyId);
//	public Company updateCompanyInfo(Company info);
//	public Company deleteCompanyInfo(String companyId);
}
