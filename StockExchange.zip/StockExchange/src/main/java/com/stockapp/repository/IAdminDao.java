package com.stockapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stockapp.entity.Admin;
@Repository
public interface IAdminDao extends JpaRepository<Admin, Integer>{
//	public Admin addAdmin(Admin admin);
//	public Admin getAdmin(Admin admin);
//	public Admin updateAdmin(Admin admin);
//	public Admin deleteAdmin(Admin admin);
}
