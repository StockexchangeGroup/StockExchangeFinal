package com.stockapp.exceptions;

public class CompanyNotFoundException extends RuntimeException {
	
	private String operation;
	public CompanyNotFoundException(String operation, String message) {
		super(message);
		this.operation = operation;
	}
	
	public String getOperation() {
		return this.operation;
	}
}


